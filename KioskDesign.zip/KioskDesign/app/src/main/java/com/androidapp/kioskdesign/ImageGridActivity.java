package com.androidapp.kioskdesign;

import android.app.Activity;
import android.os.Bundle;
import android.widget.GridView;



public class ImageGridActivity extends Activity {

    private int[] imagesIDs = new int[]{
            R.drawable.amerecano,
            R.drawable.aspresso,
            R.drawable.apogato,
            R.drawable.cafelatte,
            R.drawable.carpochino,
            R.drawable.calarmel,

    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu);

        GridView gridViewImages = (GridView) findViewById(R.id.gridViewImages);
        ImageGridAdapter imageGridAdapter = new ImageGridAdapter(this, imagesIDs);
        gridViewImages.setAdapter(imageGridAdapter);

    }
}

